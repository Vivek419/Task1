import React from 'react';
import Home from './Component/AdminRouter'
//import Home from './Component/Auth/MainPage'
function App() {
  return (
    <div >
    <Home/>
    </div>
  );
}

export default App;
