import React,{useState,useEffect} from 'react';




export default function Model(props) {
return(
    <>
    <div>
        <h4>New Education Model</h4>
    </div>
    <div>
        <input type="button" value="Save" style={{marginLeft:"90%"}}/>
    </div>
</>
);
}